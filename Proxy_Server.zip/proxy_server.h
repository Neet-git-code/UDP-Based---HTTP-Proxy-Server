// =============================================================
// proxy_server.h — Declarations for the UDP proxy server
// =============================================================

#pragma once
#include <string>
#include <cstdint>

// Maximum UDP datagram payload size (safe value under typical MTU)
static const int BUFFER_SIZE    = 4096;

// Reliability layer constants
static const int MAX_RETRIES    = 5;       // Max retransmission attempts
static const int TIMEOUT_SEC    = 3;       // Retransmission timeout in seconds

// Packet types for our custom reliability header
enum PacketType : uint8_t {
    PKT_REQUEST  = 1,   // Client → Proxy: HTTP GET request
    PKT_RESPONSE = 2,   // Proxy  → Client: HTTP response chunk
    PKT_ACK      = 3,   // Acknowledgement
    PKT_BLOCKED  = 4,   // Proxy  → Client: site is blocked
    PKT_ERROR    = 5    // Proxy  → Client: generic error
};

// ------------------------------------------------------------
// Reliability Header prepended to every UDP datagram
// Total: 6 bytes
// ------------------------------------------------------------
#pragma pack(push, 1)
struct PacketHeader {
    uint8_t  type;      // PacketType enum value
    uint32_t seqNum;    // Sequence number
    uint8_t  ackNum;    // ACK number (mirrors seqNum being acknowledged)
};
#pragma pack(pop)

// Entry point — called from main.cpp in a thread
void runProxyServer(int port);