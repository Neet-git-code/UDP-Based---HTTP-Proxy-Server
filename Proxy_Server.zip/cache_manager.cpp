// =============================================================
// cache_manager.cpp — Implementation of the response cache
// =============================================================

#include "cache_manager.h"
#include <iostream>

// Build cache key: simply "host/path"
std::string CacheManager::makeKey(const std::string& host,
                                  const std::string& path) {
    return host + path;
}

// Thread-safe cache lookup
bool CacheManager::get(const std::string& key, std::string& response) {
    std::lock_guard<std::mutex> lock(mutex_); // Auto-release on scope exit

    auto it = store_.find(key);
    if (it != store_.end()) {
        response = it->second;
        std::cout << "[CACHE] ✔  CACHE HIT  → " << key << "\n";
        return true;
    }

    std::cout << "[CACHE] ✘  CACHE MISS → " << key << "\n";
    return false;
}

// Thread-safe cache insertion
void CacheManager::put(const std::string& key, const std::string& response) {
    std::lock_guard<std::mutex> lock(mutex_);

    store_[key] = response;
    std::cout << "[CACHE] Stored response for key: " << key
              << " (" << response.size() << " bytes)\n";
}