================================================================
        UDP-BASED HTTP PROXY SERVER
        Computer Networks Course Project
        Language : C++
        Platform : Linux / macOS
================================================================

----------------------------------------------------------------
WHAT IS THIS PROJECT?
----------------------------------------------------------------

This project implements a UDP-based HTTP Proxy Server in C++.

A proxy server is a middleman between a client and the internet.
Instead of the client talking directly to a website, it sends
the request to the proxy, and the proxy fetches the response
on behalf of the client.

In this project:
  - Client talks to Proxy over UDP (unreliable transport)
  - Proxy talks to real websites over TCP (reliable transport)
  - Everything runs locally on your machine (127.0.0.1)

Flow:
  Client --UDP--> Proxy Server --TCP--> Real Website (e.g. example.com)
                       |
                  Cache Manager


----------------------------------------------------------------
PROJECT STRUCTURE
----------------------------------------------------------------

udp-proxy/
    main.cpp              Entry point, starts the proxy server
    proxy_server.h        Shared header: PacketHeader, constants
    proxy_server.cpp      Core proxy logic, UDP socket, threading
    client.cpp            UDP client with reliability layer
    parser.h              HTTP parser declarations
    parser.cpp            Parses HTTP GET requests
    cache_manager.h       Cache class declaration
    cache_manager.cpp     Thread-safe in-memory cache
    Makefile              Build system
    README.txt            This file


----------------------------------------------------------------
CONCEPTS USED
----------------------------------------------------------------

1. UDP Sockets (SOCK_DGRAM)
   - Used between client and proxy
   - Fast but unreliable, no guaranteed delivery

2. TCP Sockets (SOCK_STREAM)
   - Used between proxy and real web server
   - HTTP requires reliable transport

3. Custom Reliability Layer
   - Sequence numbers on every packet
   - ACK (acknowledgement) after every received packet
   - Retransmission if no ACK within 3 seconds
   - Max 5 retransmission attempts
   - select() used for timeout handling

4. HTTP Request Parsing
   - Reads raw HTTP GET text
   - Extracts method, host, path, port
   - Rebuilds and forwards clean HTTP request

5. Multithreading
   - One thread spawned per client request
   - All threads run simultaneously
   - Mutex used to protect shared cache

6. Caching
   - In-memory hash map (unordered_map)
   - Key = host + path
   - Value = full HTTP response
   - Prints CACHE HIT or CACHE MISS

7. Website Blocking
   - Hardcoded blocked domains list
   - Checked before every request
   - Returns BLOCKED packet immediately

8. Network Byte Order
   - htonl() before sending integers
   - ntohl() after receiving integers


----------------------------------------------------------------
REQUIREMENTS
----------------------------------------------------------------

  - Linux or macOS
  - g++ compiler with C++17 support
  - pthreads library (usually pre-installed)

  NOTE: Does NOT work natively on Windows.
        Use WSL2 or a Linux VM on Windows.


----------------------------------------------------------------
HOW TO COMPILE
----------------------------------------------------------------

Step 1 — Open terminal and go to the project folder:
    cd udp-proxy

Step 2 — Build everything with one command:
    make

    This produces two binaries:
      ./proxy    (the proxy server)
      ./client   (the client program)

To build manually without make:

    Proxy:
    g++ -std=c++17 -pthread -o proxy main.cpp proxy_server.cpp parser.cpp cache_manager.cpp

    Client:
    g++ -std=c++17 -pthread -o client client.cpp parser.cpp cache_manager.cpp

To clean up binaries:
    make clean

NOTE: Only .cpp files are compiled. .h files are automatically
      included by the compiler via #include directives.


----------------------------------------------------------------
HOW TO RUN
----------------------------------------------------------------

You need TWO terminal windows open in the project folder.

--- Terminal 1: Start the Proxy Server ---

    ./proxy 8888

    Expected output:
        ========================================
           UDP-Based HTTP Proxy Server v1.0
        ========================================
        [MAIN] Starting proxy on port 8888
        [PROXY] Listening on UDP port 8888
        [PROXY] Blocked sites: facebook.com, instagram.com, tiktok.com
        ----------------------------------------
        [MAIN] Proxy server running. Press ENTER to stop.

    Leave this running. All logs appear here.

--- Terminal 2: Run the Client ---

    Syntax:
        ./client <proxy_ip> <proxy_port> <url>

    Test 1 - Normal request (first time = CACHE MISS):
        ./client 127.0.0.1 8888 http://example.com/

    Test 2 - Same request again (CACHE HIT):
        ./client 127.0.0.1 8888 http://example.com/

    Test 3 - Test website blocking:
        ./client 127.0.0.1 8888 http://facebook.com/
        ./client 127.0.0.1 8888 http://instagram.com/

    Test 4 - Another working HTTP site:
        ./client 127.0.0.1 8888 http://neverssl.com/
        ./client 127.0.0.1 8888 http://httpbin.org/get
        ./client 127.0.0.1 8888 http://info.cern.ch/

    Test 5 - Multiple clients simultaneously:
        ./client 127.0.0.1 8888 http://example.com/ &
        ./client 127.0.0.1 8888 http://neverssl.com/ &
        ./client 127.0.0.1 8888 http://facebook.com/ &
        wait

--- Stop the Proxy ---
    Go to Terminal 1 and press ENTER.


----------------------------------------------------------------
WHAT DOES THE CLIENT RECEIVE?
----------------------------------------------------------------

The client receives raw HTTP response text printed in terminal.
It is NOT a browser. It does not render webpages.

Example output for http://example.com/ :

    HTTP/1.1 200 OK
    Content-Type: text/html; charset=UTF-8

    <!doctype html>
    <html>
    <head><title>Example Domain</title></head>
    <body>
    <h1>Example Domain</h1>
    <p>This domain is for illustrative examples...</p>
    </body>
    </html>

For http://google.com/ you get a 301 redirect because
Google only supports HTTPS, which this proxy does not implement.

Best sites to test:
    http://example.com/      Simple HTML page
    http://neverssl.com/     Designed for plain HTTP testing
    http://httpbin.org/get   Returns JSON response
    http://info.cern.ch/     World's first website, plain HTTP


----------------------------------------------------------------
SAMPLE TERMINAL LOGS
----------------------------------------------------------------

Proxy Terminal:
    [PROXY] <- Request from 127.0.0.1:54321 | seq=1 | 68 bytes
    [PROXY] -> ACK sent to 127.0.0.1 for seq=1
    [PARSER] Parsed -> Method: GET | Host: example.com | Port: 80 | Path: /
    [CACHE]  CACHE MISS -> example.com/
    [PROXY] TCP connected to example.com:80
    [PROXY] Forwarded HTTP request
    [PROXY] Received 1256 bytes from example.com
    [CACHE] Stored response for key: example.com/ (1256 bytes)
    [PROXY] -> Chunk seq=2 (1256 bytes) -> 127.0.0.1:54321
    [PROXY] -> End-of-stream sent to 127.0.0.1

Client Terminal:
    [CLIENT] -> Sent request (attempt 1) | seq=1 | 68 bytes
    [CLIENT] <- ACK received for seq=1
    [CLIENT] Receiving response...
    [CLIENT] <- Chunk seq=2 (1256 bytes)
    [CLIENT] <- End-of-stream received.

    ========== HTTP RESPONSE (1256 bytes) ==========
    HTTP/1.1 200 OK
    ...
    ================================================

Blocked site:
    [PROXY]  BLOCKED request to: facebook.com
    [CLIENT] BLOCKED: facebook.com is not accessible through this proxy.

Cache hit (second request):
    [CACHE]  CACHE HIT  -> example.com/
    (No TCP connection made, response served from memory instantly)


----------------------------------------------------------------
RELIABILITY LAYER — HOW IT WORKS
----------------------------------------------------------------

Since UDP does not guarantee delivery, we add our own:

    Client                        Proxy
      |                             |
      |-- PKT_REQUEST (seq=1) ----->|   Client sends request
      |<-- PKT_ACK (seq=1) ---------|   Proxy acknowledges
      |                             |   [Proxy fetches from web]
      |<-- PKT_RESPONSE (seq=2) ----|   Proxy sends chunk
      |-- PKT_ACK (seq=2) --------->|   Client acknowledges
      |<-- PKT_RESPONSE (empty) ----|   End of stream

If ACK is not received within 3 seconds:
    -> Sender retransmits the packet
    -> Up to 5 retransmission attempts
    -> After 5 failures: report proxy unreachable


----------------------------------------------------------------
PACKET HEADER STRUCTURE
----------------------------------------------------------------

Every UDP datagram starts with a 6-byte header:

    | type (1 byte) | seqNum (4 bytes) | ackNum (1 byte) |

Packet types:
    PKT_REQUEST  = 1   Client to Proxy: HTTP GET request
    PKT_RESPONSE = 2   Proxy to Client: HTTP response chunk
    PKT_ACK      = 3   Acknowledgement
    PKT_BLOCKED  = 4   Proxy to Client: site is blocked
    PKT_ERROR    = 5   Proxy to Client: error occurred


----------------------------------------------------------------
BLOCKED WEBSITES
----------------------------------------------------------------

The following domains are blocked by default:
    - facebook.com
    - www.facebook.com
    - instagram.com
    - www.instagram.com
    - tiktok.com
    - www.tiktok.com

To add more blocked sites, edit the BLOCKED_SITES set
in proxy_server.cpp and recompile.


----------------------------------------------------------------
KNOWN LIMITATIONS
----------------------------------------------------------------

1. Only HTTP is supported, not HTTPS (no TLS/SSL)
2. Only GET requests are supported (no POST, PUT, DELETE)
3. Cache has no expiry — entries live until proxy is restarted
4. Redirects (301/302) are not followed automatically
5. Large responses may be truncated in client display (>2000 chars)
6. Does not work on Windows without WSL2


----------------------------------------------------------------
REAL-WORLD APPLICATIONS OF THIS PROJECT
----------------------------------------------------------------

This project This Project     Real-World Equivalent
---------------------------------------------------------------------------
Proxy forwarding            VPNs, Tor, corporate proxies
Caching layer               Cloudflare CDN, browser cache
Website blocking            School/office firewalls, parental controls
Reliability over UDP        QUIC protocol (HTTP/3), game engines
Multithreaded server        Nginx, Apache web servers
HTTP parsing                Every web server ever built


----------------------------------------------------------------
QUICK REFERENCE
----------------------------------------------------------------

Command                                          What it does
------------------------------------------------------------------------
make                                             Compile everything
make clean                                       Remove binaries
./proxy 8888                                     Start proxy on port 8888
./client 127.0.0.1 8888 http://example.com/     Fetch a page
./client 127.0.0.1 8888 http://facebook.com/    Test blocking
./client 127.0.0.1 8888 http://example.com/ &   Run in background


================================================================
END OF README
================================================================