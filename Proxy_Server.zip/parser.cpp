// =============================================================
// parser.cpp — Parses simplified HTTP GET requests
//
// HTTP GET format we handle:
//   GET http://host[:port]/path HTTP/1.1
//   Host: host
//   <blank line>
//
// We extract: method, host, port, path, version.
// =============================================================

#include "parser.h"
#include <sstream>
#include <iostream>
#include <regex>

bool parseHttpRequest(const std::string& raw, HttpRequest& out) {
    // Default values
    out.port    = 80;
    out.method  = "GET";
    out.version = "HTTP/1.1";

    std::istringstream stream(raw);
    std::string requestLine;

    // Read the first line: "GET http://host/path HTTP/1.1"
    if (!std::getline(stream, requestLine)) {
        std::cerr << "[PARSER] Empty request\n";
        return false;
    }

    // Remove trailing carriage return if present
    if (!requestLine.empty() && requestLine.back() == '\r')
        requestLine.pop_back();

    std::istringstream lineStream(requestLine);
    std::string url;
    lineStream >> out.method >> url >> out.version;

    if (out.method != "GET") {
        std::cerr << "[PARSER] Only GET is supported, got: " << out.method << "\n";
        return false;
    }

    // --------------------------------------------------------
    // URL parsing: supports both:
    //   http://example.com/path
    //   example.com/path          (no scheme)
    // --------------------------------------------------------
    std::string workUrl = url;

    // Strip scheme (http:// or https://)
    auto schemePos = workUrl.find("://");
    if (schemePos != std::string::npos)
        workUrl = workUrl.substr(schemePos + 3);

    // Split host+port from path
    auto slashPos = workUrl.find('/');
    std::string hostPort;
    if (slashPos == std::string::npos) {
        hostPort  = workUrl;
        out.path  = "/";
    } else {
        hostPort  = workUrl.substr(0, slashPos);
        out.path  = workUrl.substr(slashPos);   // includes leading '/'
    }

    // Extract port if specified (host:port)
    auto colonPos = hostPort.find(':');
    if (colonPos != std::string::npos) {
        out.host = hostPort.substr(0, colonPos);
        try {
            out.port = std::stoi(hostPort.substr(colonPos + 1));
        } catch (...) {
            out.port = 80;
        }
    } else {
        out.host = hostPort;
    }

    if (out.host.empty()) {
        std::cerr << "[PARSER] Could not extract host from URL: " << url << "\n";
        return false;
    }

    std::cout << "[PARSER] Parsed → Method: " << out.method
              << " | Host: " << out.host
              << " | Port: " << out.port
              << " | Path: " << out.path << "\n";
    return true;
}

// Build the HTTP GET request we forward to the real server
std::string buildForwardRequest(const HttpRequest& req) {
    std::ostringstream ss;
    ss << "GET " << req.path << " HTTP/1.1\r\n";
    ss << "Host: " << req.host << "\r\n";
    ss << "Connection: close\r\n";          // Tell server to close after response
    ss << "User-Agent: UDP-Proxy/1.0\r\n";
    ss << "\r\n";                            // Blank line ends HTTP headers
    return ss.str();
}