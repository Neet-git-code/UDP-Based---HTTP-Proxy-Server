// =============================================================
// parser.h — HTTP request parser declarations
// =============================================================

#pragma once
#include <string>

// Holds the parsed components of an HTTP GET request
struct HttpRequest {
    std::string method;  // e.g. "GET"
    std::string host;    // e.g. "example.com"
    std::string path;    // e.g. "/index.html"
    std::string version; // e.g. "HTTP/1.1"
    int         port;    // usually 80
};

// Parse a raw HTTP request string into an HttpRequest struct.
// Returns false if parsing fails.
bool parseHttpRequest(const std::string& raw, HttpRequest& out);

// Build a well-formed HTTP GET request string to forward upstream
std::string buildForwardRequest(const HttpRequest& req);