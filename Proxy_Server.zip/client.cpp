// =============================================================
// client.cpp — UDP client that sends HTTP GET requests
//              through the proxy server
//
// Reliability layer:
//   1. Send request datagram with a sequence number
//   2. Wait up to TIMEOUT_SEC seconds for ACK
//   3. If no ACK → retransmit (up to MAX_RETRIES times)
//   4. After ACK, receive response chunks until end-of-stream
//   5. ACK each response chunk back to proxy
// =============================================================

#include "proxy_server.h" // Shared header, PacketHeader, constants

#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>

// POSIX socket headers
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <sys/select.h>

// ---------------------------------------------------------------
// Build a raw datagram: PacketHeader + payload
// ---------------------------------------------------------------
static std::string buildPacket(PacketType type,
                                uint32_t seqNum,
                                uint8_t  ackNum,
                                const std::string& payload) {
    PacketHeader hdr;
    hdr.type   = static_cast<uint8_t>(type);
    hdr.seqNum = htonl(seqNum);
    hdr.ackNum = ackNum;

    std::string pkt(reinterpret_cast<char*>(&hdr), sizeof(hdr));
    pkt += payload;
    return pkt;
}

// ---------------------------------------------------------------
// Wait for a UDP datagram with a timeout (uses select())
// Returns number of bytes received, or -1 on timeout/error
// ---------------------------------------------------------------
static ssize_t recvWithTimeout(int sock,
                               char* buf,
                               size_t bufLen,
                               int timeoutSec) {
    fd_set readfds;
    FD_ZERO(&readfds);
    FD_SET(sock, &readfds);

    timeval tv{};
    tv.tv_sec  = timeoutSec;
    tv.tv_usec = 0;

    int ready = select(sock + 1, &readfds, nullptr, nullptr, &tv);
    if (ready <= 0) return -1; // Timeout or error

    return recv(sock, buf, bufLen, 0);
}

// ---------------------------------------------------------------
// Main client logic
// Usage: ./client <proxy_ip> <proxy_port> <url>
// Example: ./client 127.0.0.1 8888 http://example.com/
// ---------------------------------------------------------------
int main(int argc, char* argv[]) {
    if (argc < 4) {
        std::cerr << "Usage: " << argv[0]
                  << " <proxy_ip> <proxy_port> <url>\n";
        std::cerr << "Example: ./client 127.0.0.1 8888 http://example.com/\n";
        return 1;
    }

    const char* proxyIP   = argv[1];
    int         proxyPort = std::stoi(argv[2]);
    std::string url       = argv[3];

    std::cout << "========================================\n";
    std::cout << "   UDP Proxy Client\n";
    std::cout << "========================================\n";
    std::cout << "[CLIENT] Proxy: " << proxyIP << ":" << proxyPort << "\n";
    std::cout << "[CLIENT] URL  : " << url << "\n\n";

    // Build simplified HTTP GET request
    std::string httpRequest = "GET " + url + " HTTP/1.1\r\n";
    httpRequest += "Host: placeholder\r\n";
    httpRequest += "Connection: close\r\n\r\n";

    // Create UDP socket
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        std::cerr << "[CLIENT] socket() failed\n";
        return 1;
    }

    // Proxy server address
    sockaddr_in proxyAddr{};
    proxyAddr.sin_family = AF_INET;
    proxyAddr.sin_port   = htons(proxyPort);
    if (inet_pton(AF_INET, proxyIP, &proxyAddr.sin_addr) <= 0) {
        std::cerr << "[CLIENT] Invalid proxy IP\n";
        close(sock);
        return 1;
    }

    // Connect UDP socket to proxy (optional but simplifies recv)
    connect(sock, reinterpret_cast<sockaddr*>(&proxyAddr), sizeof(proxyAddr));

    // -------------------------------------------------------
    // STEP 1 — Send request with reliability (ACK wait + retry)
    // -------------------------------------------------------
    uint32_t seqNum = 1; // Starting sequence number
    bool     acked  = false;

    for (int attempt = 1; attempt <= MAX_RETRIES && !acked; attempt++) {
        std::string pkt = buildPacket(PKT_REQUEST, seqNum, 0, httpRequest);

        ssize_t sent = send(sock, pkt.c_str(), pkt.size(), 0);
        std::cout << "[CLIENT] → Sent request (attempt " << attempt
                  << ") | seq=" << seqNum
                  << " | " << sent << " bytes\n";

        // Wait for ACK
        char ackBuf[64];
        ssize_t n = recvWithTimeout(sock, ackBuf, sizeof(ackBuf), TIMEOUT_SEC);

        if (n < static_cast<ssize_t>(sizeof(PacketHeader))) {
            std::cout << "[CLIENT] ⚠  Timeout waiting for ACK, retrying...\n";
            continue;
        }

        PacketHeader ackHdr;
        std::memcpy(&ackHdr, ackBuf, sizeof(ackHdr));

        if (ackHdr.type == PKT_ACK && ntohl(ackHdr.seqNum) == seqNum) {
            std::cout << "[CLIENT] ← ACK received for seq=" << seqNum << "\n";
            acked = true;
        } else {
            std::cout << "[CLIENT] Unexpected packet type="
                      << (int)ackHdr.type << ", retrying...\n";
        }
    }

    if (!acked) {
        std::cerr << "[CLIENT] ✗ Failed to get ACK after "
                  << MAX_RETRIES << " attempts. Proxy unreachable.\n";
        close(sock);
        return 1;
    }

    // -------------------------------------------------------
    // STEP 2 — Receive response chunks until end-of-stream
    // -------------------------------------------------------
    std::string fullResponse;
    std::cout << "\n[CLIENT] Receiving response...\n";

    while (true) {
        char buf[BUFFER_SIZE + sizeof(PacketHeader)];
        ssize_t n = recvWithTimeout(sock, buf, sizeof(buf), TIMEOUT_SEC * 2);

        if (n < 0) {
            std::cout << "[CLIENT] Timeout waiting for response chunk. Done.\n";
            break;
        }

        if (n < static_cast<ssize_t>(sizeof(PacketHeader))) continue;

        PacketHeader hdr;
        std::memcpy(&hdr, buf, sizeof(hdr));
        uint32_t    pktSeq  = ntohl(hdr.seqNum);
        std::string payload = std::string(buf + sizeof(PacketHeader),
                                          n - sizeof(PacketHeader));

        // Handle BLOCKED response
        if (hdr.type == PKT_BLOCKED) {
            std::cout << "\n[CLIENT] ⛔ " << payload << "\n";
            break;
        }

        // Handle ERROR response
        if (hdr.type == PKT_ERROR) {
            std::cout << "\n[CLIENT] ✗ Error from proxy: " << payload << "\n";
            break;
        }

        // Handle RESPONSE chunk
        if (hdr.type == PKT_RESPONSE) {
            if (payload.empty()) {
                // Empty payload = end-of-stream sentinel
                std::cout << "[CLIENT] ← End-of-stream received.\n";
                break;
            }

            fullResponse += payload;
            std::cout << "[CLIENT] ← Chunk seq=" << pktSeq
                      << " (" << payload.size() << " bytes)\n";

            // Send ACK back to proxy for this chunk
            std::string ackPkt = buildPacket(PKT_ACK, pktSeq, 0, "ACK");
            send(sock, ackPkt.c_str(), ackPkt.size(), 0);
        }
    }

    // -------------------------------------------------------
    // STEP 3 — Display the response
    // -------------------------------------------------------
    std::cout << "\n========== HTTP RESPONSE (" 
              << fullResponse.size() << " bytes) ==========\n";

    // Print only the first 2000 chars to keep terminal readable
    if (fullResponse.size() > 2000) {
        std::cout << fullResponse.substr(0, 2000) << "\n...[truncated]\n";
    } else {
        std::cout << fullResponse << "\n";
    }

    std::cout << "==========================================\n";
    close(sock);
    return 0;
}