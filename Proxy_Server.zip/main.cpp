// =============================================================
// main.cpp — Entry point for the UDP-Based HTTP Proxy Server
// Starts the proxy server in a separate thread, then loops
// to accept commands or simply keeps the process alive.
// =============================================================

#include <iostream>
#include <thread>
#include <string>
#include "proxy_server.h"

int main(int argc, char* argv[]) {
    int port = 8888; // Default proxy port

    if (argc >= 2) {
        port = std::stoi(argv[1]);
    }

    std::cout << "========================================\n";
    std::cout << "   UDP-Based HTTP Proxy Server v1.0\n";
    std::cout << "========================================\n";
    std::cout << "[MAIN] Starting proxy on port " << port << "\n";

    // Launch proxy server in its own thread so main stays responsive
    std::thread serverThread(runProxyServer, port);

    std::cout << "[MAIN] Proxy server running. Press ENTER to stop.\n";
    std::cin.get();

    std::cout << "[MAIN] Shutting down proxy server...\n";
    serverThread.detach(); // Let OS clean up on exit
    return 0;
}