// =============================================================
// cache_manager.h — Simple in-memory HTTP response cache
//
// Key   : "host + path"  (e.g. "example.com/index.html")
// Value : raw HTTP response string
//
// Thread-safe via std::mutex — multiple proxy threads can
// read/write the cache concurrently without data races.
// =============================================================

#pragma once
#include <string>
#include <unordered_map>
#include <mutex>

class CacheManager {
public:
    // Check if a response for this key exists in cache.
    // Returns true + fills 'response' on HIT; prints CACHE HIT/MISS.
    bool get(const std::string& key, std::string& response);

    // Store a response in the cache under the given key.
    void put(const std::string& key, const std::string& response);

    // Build a canonical cache key from host + path
    static std::string makeKey(const std::string& host, const std::string& path);

private:
    std::unordered_map<std::string, std::string> store_; // key → response
    std::mutex mutex_;                                    // guards store_
};