// =============================================================
// proxy_server.cpp — Core of the UDP-Based HTTP Proxy Server
//
// Architecture overview:
//   Client ──UDP──► ProxyServer ──TCP──► Real Web Server
//                        │
//                   CacheManager
//
// UDP is inherently unreliable, so we add a simple reliability
// layer on top:
//   • Every datagram carries a PacketHeader (type + seqNum + ackNum)
//   • Proxy sends ACK after receiving a client packet
//   • Client retransmits if no ACK arrives within TIMEOUT_SEC
//   • Proxy sends response with seqNum; client ACKs it
//
// Multithreading:
//   The main UDP socket is shared; for each incoming client packet
//   a new std::thread handles parsing, caching, and forwarding.
//   The CacheManager is protected by a mutex.
// =============================================================

#include "proxy_server.h"
#include "parser.h"
#include "cache_manager.h"

#include <iostream>
#include <string>
#include <thread>
#include <unordered_set>
#include <cstring>
#include <sstream>

// POSIX / BSD socket headers (Linux / macOS)
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>

// ---------------------------------------------------------------
// Globally blocked domains list
// ---------------------------------------------------------------
static const std::unordered_set<std::string> BLOCKED_SITES = {
    "facebook.com",
    "www.facebook.com",
    "instagram.com",
    "www.instagram.com",
    "tiktok.com",
    "www.tiktok.com"
};

// Global cache — shared across all threads
static CacheManager gCache;

// ---------------------------------------------------------------
// Utility: send a UDP datagram with our reliability header
// ---------------------------------------------------------------
static void sendPacket(int sock,
                       const sockaddr_in& dest,
                       PacketType type,
                       uint32_t seqNum,
                       uint8_t  ackNum,
                       const std::string& payload) {
    // Build raw buffer: header + payload
    PacketHeader hdr;
    hdr.type   = static_cast<uint8_t>(type);
    hdr.seqNum = htonl(seqNum);   // Network byte order (big-endian)
    hdr.ackNum = ackNum;

    std::string packet(reinterpret_cast<char*>(&hdr), sizeof(hdr));
    packet += payload;

    ssize_t sent = sendto(sock,
                          packet.c_str(),
                          packet.size(),
                          0,
                          reinterpret_cast<const sockaddr*>(&dest),
                          sizeof(dest));
    if (sent < 0)
        std::cerr << "[PROXY] sendto() failed\n";
}

// ---------------------------------------------------------------
// Forward HTTP request over TCP to the real server, return response
// ---------------------------------------------------------------
static std::string forwardToServer(const HttpRequest& req) {
    // Resolve hostname → IP address
    struct addrinfo hints{}, *res = nullptr;
    hints.ai_family   = AF_INET;
    hints.ai_socktype = SOCK_STREAM; // TCP for real HTTP

    std::string portStr = std::to_string(req.port);
    if (getaddrinfo(req.host.c_str(), portStr.c_str(), &hints, &res) != 0) {
        std::cerr << "[PROXY] DNS resolution failed for: " << req.host << "\n";
        return "";
    }

    // Create TCP socket
    int tcpSock = socket(AF_INET, SOCK_STREAM, 0);
    if (tcpSock < 0) {
        freeaddrinfo(res);
        return "";
    }

    // Connect to the web server
    if (connect(tcpSock, res->ai_addr, res->ai_addrlen) < 0) {
        std::cerr << "[PROXY] TCP connect failed to " << req.host << "\n";
        close(tcpSock);
        freeaddrinfo(res);
        return "";
    }
    freeaddrinfo(res);

    std::cout << "[PROXY] TCP connected to " << req.host << ":" << req.port << "\n";

    // Send the HTTP GET request
    std::string httpReq = buildForwardRequest(req);
    send(tcpSock, httpReq.c_str(), httpReq.size(), 0);
    std::cout << "[PROXY] Forwarded HTTP request:\n" << httpReq;

    // Read the full response (may arrive in multiple TCP segments)
    std::string response;
    char buf[BUFFER_SIZE];
    ssize_t n;
    while ((n = recv(tcpSock, buf, sizeof(buf), 0)) > 0) {
        response.append(buf, n);
    }

    close(tcpSock);
    std::cout << "[PROXY] Received " << response.size()
              << " bytes from " << req.host << "\n";
    return response;
}

// ---------------------------------------------------------------
// Per-client handler — runs in its own thread
// Receives exactly one request datagram and sends back response.
// ---------------------------------------------------------------
static void handleClient(int proxySock,
                         sockaddr_in clientAddr,
                         std::string rawPacket) {
    // --- Decode reliability header ---
    if (rawPacket.size() < sizeof(PacketHeader)) {
        std::cerr << "[PROXY] Packet too small, dropping\n";
        return;
    }

    PacketHeader hdr;
    std::memcpy(&hdr, rawPacket.data(), sizeof(hdr));
    uint32_t seqNum = ntohl(hdr.seqNum);    // Convert from network byte order

    std::string payload = rawPacket.substr(sizeof(PacketHeader));

    char clientIP[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &clientAddr.sin_addr, clientIP, sizeof(clientIP));
    int clientPort = ntohs(clientAddr.sin_port);

    std::cout << "[PROXY] ← Request from " << clientIP << ":" << clientPort
              << " | seq=" << seqNum
              << " | " << payload.size() << " bytes\n";

    // --- Send ACK back to client immediately ---
    // ACK tells the client "I received your packet seqNum"
    sendPacket(proxySock, clientAddr,
               PKT_ACK, seqNum, static_cast<uint8_t>(seqNum), "ACK");
    std::cout << "[PROXY] → ACK sent to " << clientIP
              << " for seq=" << seqNum << "\n";

    // --- Parse the HTTP request ---
    HttpRequest httpReq;
    if (!parseHttpRequest(payload, httpReq)) {
        std::string errMsg = "HTTP/1.1 400 Bad Request\r\n\r\nInvalid request";
        sendPacket(proxySock, clientAddr, PKT_ERROR, seqNum + 1, 0, errMsg);
        return;
    }

    // --- Check if the host is blocked ---
    if (BLOCKED_SITES.count(httpReq.host)) {
        std::cout << "[PROXY] ⛔ BLOCKED request to: " << httpReq.host << "\n";
        std::string blockMsg = "BLOCKED: " + httpReq.host +
                               " is not accessible through this proxy.";
        sendPacket(proxySock, clientAddr, PKT_BLOCKED, seqNum + 1, 0, blockMsg);
        return;
    }

    // --- Check cache ---
    std::string cacheKey = CacheManager::makeKey(httpReq.host, httpReq.path);
    std::string httpResponse;

    if (!gCache.get(cacheKey, httpResponse)) {
        // Cache miss — fetch from real server
        httpResponse = forwardToServer(httpReq);
        if (httpResponse.empty()) {
            std::string errMsg = "HTTP/1.1 502 Bad Gateway\r\n\r\nCould not reach server";
            sendPacket(proxySock, clientAddr, PKT_ERROR, seqNum + 1, 0, errMsg);
            return;
        }
        // Store in cache for future requests
        gCache.put(cacheKey, httpResponse);
    }

    // --- Send response back to client ---
    // UDP max payload ≈ 65507 bytes; we chunk the response if needed
    const size_t CHUNK = BUFFER_SIZE - sizeof(PacketHeader);
    uint32_t respSeq   = seqNum + 1;
    size_t   offset    = 0;

    while (offset < httpResponse.size()) {
        std::string chunk = httpResponse.substr(offset, CHUNK);
        offset += chunk.size();

        sendPacket(proxySock, clientAddr, PKT_RESPONSE, respSeq, 0, chunk);
        std::cout << "[PROXY] → Chunk seq=" << respSeq
                  << " (" << chunk.size() << " bytes) → "
                  << clientIP << ":" << clientPort << "\n";
        respSeq++;

        // Small delay between chunks to avoid flooding the client
        usleep(5000); // 5 ms
    }

    // Send an empty PKT_RESPONSE as end-of-stream marker
    sendPacket(proxySock, clientAddr, PKT_RESPONSE, respSeq, 0, "");
    std::cout << "[PROXY] → End-of-stream sent to " << clientIP << "\n";
}

// ---------------------------------------------------------------
// runProxyServer — binds UDP socket, loops receiving datagrams,
// spawns a thread for each client request
// ---------------------------------------------------------------
void runProxyServer(int port) {
    // Create UDP socket
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        std::cerr << "[PROXY] socket() failed\n";
        return;
    }

    // Allow port reuse after quick restart
    int opt = 1;
    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    // Bind to all interfaces on the given port
    sockaddr_in serverAddr{};
    serverAddr.sin_family      = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port        = htons(port);

    if (bind(sock, reinterpret_cast<sockaddr*>(&serverAddr),
             sizeof(serverAddr)) < 0) {
        std::cerr << "[PROXY] bind() failed on port " << port << "\n";
        close(sock);
        return;
    }

    std::cout << "[PROXY] Listening on UDP port " << port << "\n";
    std::cout << "[PROXY] Blocked sites: facebook.com, instagram.com, tiktok.com\n";
    std::cout << "----------------------------------------\n";

    // Main receive loop — one iteration per incoming datagram
    while (true) {
        char buf[BUFFER_SIZE + sizeof(PacketHeader)];
        sockaddr_in clientAddr{};
        socklen_t   addrLen = sizeof(clientAddr);

        ssize_t n = recvfrom(sock, buf, sizeof(buf), 0,
                             reinterpret_cast<sockaddr*>(&clientAddr),
                             &addrLen);
        if (n <= 0) continue;

        std::string rawPacket(buf, n);

        // Spawn thread — each client request handled independently
        // Detach so we don't need to join later
        std::thread t(handleClient, sock, clientAddr, rawPacket);
        t.detach();
    }

    close(sock);
}